import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import JobCard from './components/JobCard';
import JobForm from './components/JobForm';
import JobDetails from './components/JobDetails';
import JobFilters from './components/JobFilters';
import JobStats from './components/JobStats';
import BulkActions from './components/BulkActions';

const JobManagement = () => {
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingJob, setEditingJob] = useState(null);
  const [selectedJobs, setSelectedJobs] = useState([]);
  const [activeTab, setActiveTab] = useState('list'); // For mobile: 'list' or 'details'
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [technicianFilter, setTechnicianFilter] = useState('');
  const [sortBy, setSortBy] = useState('newest');

  // Mock data initialization
  useEffect(() => {
    const mockJobs = [
      {
        id: 'JOB001',
        customerId: 'CUST001',
        customerName: 'John Smith',
        customerPhone: '+1 (555) 123-4567',
        customerEmail: 'john.smith@email.com',
        vehicle: '2020 Toyota Camry',
        vehicleModel: 'Toyota Camry',
        vehiclePlate: 'ABC-123',
        vehicleYear: '2020',
        status: 'In Progress',
        priority: 'High',
        technician: 'Mike Johnson',
        technicianId: 'TECH001',
        technicianSpecialization: 'Engine Specialist',
        serviceDescription: 'Engine diagnostic and oil change. Customer reports unusual noise from engine bay during acceleration.',
        estimatedHours: 3,
        estimatedCost: 250,
        dueDate: '2024-01-15',
        createdDate: '2024-01-12',
        progress: 65,
        timeSpent: 120,
        vehiclePhotos: [
          { id: 1, url: 'https://images.pexels.com/photos/3806288/pexels-photo-3806288.jpeg', name: 'engine_bay.jpg' },
          { id: 2, url: 'https://images.pexels.com/photos/4489702/pexels-photo-4489702.jpeg', name: 'dashboard.jpg' }
        ],
        notes: [
          {
            id: 1,
            author: 'Mike Johnson',
            content: 'Started engine diagnostic. Found minor oil leak in valve cover gasket.',
            timestamp: '2024-01-12 10:30 AM'
          },
          {
            id: 2,
            author: 'Mike Johnson',
            content: 'Oil change completed. Gasket replacement in progress.',
            timestamp: '2024-01-12 2:15 PM'
          }
        ]
      },
      {
        id: 'JOB002',
        customerId: 'CUST002',
        customerName: 'Sarah Davis',
        customerPhone: '+1 (555) 987-6543',
        customerEmail: 'sarah.davis@email.com',
        vehicle: '2019 Honda Civic',
        vehicleModel: 'Honda Civic',
        vehiclePlate: 'XYZ-789',
        vehicleYear: '2019',
        status: 'Pending',
        priority: 'Medium',
        technician: 'Alex Rodriguez',
        technicianId: 'TECH002',
        technicianSpecialization: 'Brake Specialist',
        serviceDescription: 'Brake pad replacement and brake fluid flush. Customer reports squeaking noise when braking.',
        estimatedHours: 2,
        estimatedCost: 180,
        dueDate: '2024-01-16',
        createdDate: '2024-01-13',
        progress: 0,
        timeSpent: 0,
        vehiclePhotos: [],
        notes: []
      },
      {
        id: 'JOB003',
        customerId: 'CUST003',
        customerName: 'Robert Wilson',
        customerPhone: '+1 (555) 456-7890',
        customerEmail: 'robert.wilson@email.com',
        vehicle: '2021 Ford F-150',
        vehicleModel: 'Ford F-150',
        vehiclePlate: 'DEF-456',
        vehicleYear: '2021',
        status: 'Completed',
        priority: 'Low',
        technician: 'Carlos Martinez',
        technicianId: 'TECH003',
        technicianSpecialization: 'Transmission Specialist',
        serviceDescription: 'Routine maintenance: oil change, tire rotation, and multi-point inspection.',
        estimatedHours: 1.5,
        estimatedCost: 120,
        dueDate: '2024-01-14',
        createdDate: '2024-01-11',
        progress: 100,
        timeSpent: 90,
        vehiclePhotos: [],
        notes: [
          {
            id: 1,
            author: 'Carlos Martinez',
            content: 'All routine maintenance completed successfully. Vehicle in excellent condition.',
            timestamp: '2024-01-14 11:45 AM'
          }
        ]
      },
      {
        id: 'JOB004',
        customerId: 'CUST004',
        customerName: 'Emily Johnson',
        customerPhone: '+1 (555) 321-0987',
        customerEmail: 'emily.johnson@email.com',
        vehicle: '2018 BMW X3',
        vehicleModel: 'BMW X3',
        vehiclePlate: 'GHI-789',
        vehicleYear: '2018',
        status: 'In Progress',
        priority: 'High',
        technician: 'David Kim',
        technicianId: 'TECH004',
        technicianSpecialization: 'Electrical Systems',
        serviceDescription: 'Electrical system diagnostic. Customer reports intermittent starting issues and dashboard warning lights.',
        estimatedHours: 4,
        estimatedCost: 350,
        dueDate: '2024-01-17',
        createdDate: '2024-01-13',
        progress: 25,
        timeSpent: 60,
        vehiclePhotos: [
          { id: 1, url: 'https://images.pexels.com/photos/3806288/pexels-photo-3806288.jpeg', name: 'dashboard_lights.jpg' }
        ],
        notes: [
          {
            id: 1,
            author: 'David Kim',
            content: 'Initial diagnostic shows potential alternator issues. Running comprehensive electrical test.',
            timestamp: '2024-01-13 9:15 AM'
          }
        ]
      },
      {
        id: 'JOB005',
        customerId: 'CUST005',
        customerName: 'Michael Brown',
        customerPhone: '+1 (555) 654-3210',
        customerEmail: 'michael.brown@email.com',
        vehicle: '2022 Tesla Model 3',
        vehicleModel: 'Tesla Model 3',
        vehiclePlate: 'JKL-012',
        vehicleYear: '2022',
        status: 'Pending',
        priority: 'Medium',
        technician: 'Lisa Chen',
        technicianId: 'TECH005',
        technicianSpecialization: 'EV Specialist',
        serviceDescription: 'Software update and battery health check. Customer wants to ensure optimal performance.',
        estimatedHours: 1,
        estimatedCost: 80,
        dueDate: '2024-01-18',
        createdDate: '2024-01-14',
        progress: 0,
        timeSpent: 0,
        vehiclePhotos: [],
        notes: []
      }
    ];

    const mockCustomers = [
      { id: 'CUST001', name: 'John Smith', phone: '+1 (555) 123-4567', email: 'john.smith@email.com' },
      { id: 'CUST002', name: 'Sarah Davis', phone: '+1 (555) 987-6543', email: 'sarah.davis@email.com' },
      { id: 'CUST003', name: 'Robert Wilson', phone: '+1 (555) 456-7890', email: 'robert.wilson@email.com' },
      { id: 'CUST004', name: 'Emily Johnson', phone: '+1 (555) 321-0987', email: 'emily.johnson@email.com' },
      { id: 'CUST005', name: 'Michael Brown', phone: '+1 (555) 654-3210', email: 'michael.brown@email.com' },
      { id: 'CUST006', name: 'Jennifer Garcia', phone: '+1 (555) 789-0123', email: 'jennifer.garcia@email.com' },
      { id: 'CUST007', name: 'Christopher Lee', phone: '+1 (555) 234-5678', email: 'christopher.lee@email.com' }
    ];

    const mockTechnicians = [
      { id: 'TECH001', name: 'Mike Johnson', specialization: 'Engine Specialist', status: 'Available' },
      { id: 'TECH002', name: 'Alex Rodriguez', specialization: 'Brake Specialist', status: 'Busy' },
      { id: 'TECH003', name: 'Carlos Martinez', specialization: 'Transmission Specialist', status: 'Available' },
      { id: 'TECH004', name: 'David Kim', specialization: 'Electrical Systems', status: 'Busy' },
      { id: 'TECH005', name: 'Lisa Chen', specialization: 'EV Specialist', status: 'Available' },
      { id: 'TECH006', name: 'James Wilson', specialization: 'General Mechanic', status: 'Available' }
    ];

    setJobs(mockJobs);
    setCustomers(mockCustomers);
    setTechnicians(mockTechnicians);
  }, []);

  // Filter and sort jobs
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = !searchTerm || 
      job.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.vehicle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.serviceDescription.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = !statusFilter || job.status === statusFilter;
    const matchesPriority = !priorityFilter || job.priority === priorityFilter;
    const matchesTechnician = !technicianFilter || job.technicianId === technicianFilter;
    
    return matchesSearch && matchesStatus && matchesPriority && matchesTechnician;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.createdDate) - new Date(a.createdDate);
      case 'oldest':
        return new Date(a.createdDate) - new Date(b.createdDate);
      case 'priority':
        const priorityOrder = { 'High': 3, 'Medium': 2, 'Low': 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      case 'dueDate':
        return new Date(a.dueDate) - new Date(b.dueDate);
      case 'customer':
        return a.customerName.localeCompare(b.customerName);
      default:
        return 0;
    }
  });

  const handleJobSelect = (job) => {
    setSelectedJob(job);
    setActiveTab('details');
  };

  const handleCreateJob = () => {
    setShowForm(true);
    setEditingJob(null);
    setSelectedJob(null);
  };

  const handleEditJob = (job) => {
    setEditingJob(job);
    setShowForm(true);
  };

  const handleSaveJob = (formData) => {
    if (editingJob) {
      // Update existing job
      setJobs(prev => prev.map(job => 
        job.id === editingJob.id 
          ? { ...job, ...formData, id: editingJob.id }
          : job
      ));
    } else {
      // Create new job
      const newJob = {
        ...formData,
        id: `JOB${String(jobs.length + 1).padStart(3, '0')}`,
        status: 'Pending',
        progress: 0,
        timeSpent: 0,
        createdDate: new Date().toISOString().split('T')[0],
        notes: []
      };
      setJobs(prev => [...prev, newJob]);
    }
    
    setShowForm(false);
    setEditingJob(null);
  };

  const handleStatusUpdate = (jobId, newStatus) => {
    setJobs(prev => prev.map(job => 
      job.id === jobId 
        ? { 
            ...job, 
            status: newStatus,
            progress: newStatus === 'Completed' ? 100 : job.progress
          }
        : job
    ));
    
    // Update selected job if it's the one being updated
    if (selectedJob && selectedJob.id === jobId) {
      setSelectedJob(prev => ({ 
        ...prev, 
        status: newStatus,
        progress: newStatus === 'Completed' ? 100 : prev.progress
      }));
    }
  };

  const handleAddNote = (jobId, noteContent) => {
    const newNote = {
      id: Date.now(),
      author: 'Current User',
      content: noteContent,
      timestamp: new Date().toLocaleString()
    };

    setJobs(prev => prev.map(job => 
      job.id === jobId 
        ? { ...job, notes: [...(job.notes || []), newNote] }
        : job
    ));

    // Update selected job if it's the one being updated
    if (selectedJob && selectedJob.id === jobId) {
      setSelectedJob(prev => ({ 
        ...prev, 
        notes: [...(prev.notes || []), newNote]
      }));
    }
  };

  const handleBulkStatusUpdate = (newStatus) => {
    setJobs(prev => prev.map(job => 
      selectedJobs.includes(job.id)
        ? { 
            ...job, 
            status: newStatus,
            progress: newStatus === 'Completed' ? 100 : job.progress
          }
        : job
    ));
    setSelectedJobs([]);
  };

  const handleBulkDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${selectedJobs.length} job(s)?`)) {
      setJobs(prev => prev.filter(job => !selectedJobs.includes(job.id)));
      setSelectedJobs([]);
      if (selectedJob && selectedJobs.includes(selectedJob.id)) {
        setSelectedJob(null);
      }
    }
  };

  const handleJobSelection = (jobId, isSelected) => {
    if (isSelected) {
      setSelectedJobs(prev => [...prev, jobId]);
    } else {
      setSelectedJobs(prev => prev.filter(id => id !== jobId));
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('');
    setPriorityFilter('');
    setTechnicianFilter('');
    setSortBy('newest');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          
          {/* Page Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-heading-bold text-text-primary">Job Management</h1>
              <p className="text-text-secondary mt-1">Create, track, and manage service jobs</p>
            </div>
            <Button variant="primary" onClick={handleCreateJob}>
              <Icon name="Plus" size={20} className="mr-2" />
              Create Job
            </Button>
          </div>

          {/* Job Statistics */}
          <JobStats jobs={jobs} />

          {/* Mobile Tab Navigation */}
          <div className="lg:hidden mb-6">
            <div className="flex bg-surface rounded-lg border border-border p-1">
              <button
                onClick={() => setActiveTab('list')}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-body-medium transition-colors ${
                  activeTab === 'list' ?'bg-primary text-primary-foreground' :'text-text-secondary hover:text-text-primary'
                }`}
              >
                Jobs List
              </button>
              <button
                onClick={() => setActiveTab('details')}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-body-medium transition-colors ${
                  activeTab === 'details' ?'bg-primary text-primary-foreground' :'text-text-secondary hover:text-text-primary'
                }`}
                disabled={!selectedJob}
              >
                Job Details
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Panel - Job List */}
            <div className={`lg:col-span-4 ${activeTab === 'details' ? 'hidden lg:block' : ''}`}>
              <div className="space-y-4">
                {/* Filters */}
                <JobFilters
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  statusFilter={statusFilter}
                  onStatusFilterChange={setStatusFilter}
                  priorityFilter={priorityFilter}
                  onPriorityFilterChange={setPriorityFilter}
                  technicianFilter={technicianFilter}
                  onTechnicianFilterChange={setTechnicianFilter}
                  sortBy={sortBy}
                  onSortChange={setSortBy}
                  onClearFilters={clearFilters}
                  technicians={technicians}
                />

                {/* Bulk Actions */}
                <BulkActions
                  selectedJobs={selectedJobs}
                  onBulkStatusUpdate={handleBulkStatusUpdate}
                  onBulkDelete={handleBulkDelete}
                  onClearSelection={() => setSelectedJobs([])}
                />

                {/* Job Cards */}
                <div className="space-y-3 max-h-[calc(100vh-400px)] overflow-y-auto">
                  {filteredJobs.length > 0 ? (
                    filteredJobs.map(job => (
                      <div key={job.id} className="relative">
                        <input
                          type="checkbox"
                          checked={selectedJobs.includes(job.id)}
                          onChange={(e) => handleJobSelection(job.id, e.target.checked)}
                          className="absolute top-3 right-3 z-10 w-4 h-4 text-accent bg-surface border-border rounded focus:ring-accent focus:ring-2"
                        />
                        <JobCard
                          job={job}
                          onSelect={handleJobSelect}
                          isSelected={selectedJob?.id === job.id}
                          onStatusUpdate={handleStatusUpdate}
                        />
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12 text-text-secondary">
                      <Icon name="Search" size={48} className="mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-body-medium">No jobs found</p>
                      <p className="text-sm">Try adjusting your search or filters</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Panel - Job Details/Form */}
            <div className={`lg:col-span-8 ${activeTab === 'list' ? 'hidden lg:block' : ''}`}>
              {showForm ? (
                <JobForm
                  job={editingJob}
                  onSave={handleSaveJob}
                  onCancel={() => {
                    setShowForm(false);
                    setEditingJob(null);
                  }}
                  customers={customers}
                  technicians={technicians}
                  isEditing={!!editingJob}
                />
              ) : selectedJob ? (
                <JobDetails
                  job={selectedJob}
                  onEdit={handleEditJob}
                  onStatusUpdate={handleStatusUpdate}
                  onAddNote={handleAddNote}
                />
              ) : (
                <div className="bg-surface rounded-lg border border-border p-12 text-center">
                  <Icon name="Clipboard" size={64} className="mx-auto mb-4 text-text-secondary opacity-50" />
                  <h3 className="text-xl font-heading-medium text-text-primary mb-2">
                    Select a job to view details
                  </h3>
                  <p className="text-text-secondary mb-6">
                    Choose a job from the list to see detailed information and manage it
                  </p>
                  <Button variant="primary" onClick={handleCreateJob}>
                    <Icon name="Plus" size={20} className="mr-2" />
                    Create New Job
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default JobManagement;