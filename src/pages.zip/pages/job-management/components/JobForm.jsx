import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const JobForm = ({ job, onSave, onCancel, customers, technicians, isEditing = false }) => {
  const [formData, setFormData] = useState({
    customerId: job?.customerId || '',
    customerName: job?.customerName || '',
    vehicleModel: job?.vehicleModel || '',
    vehiclePlate: job?.vehiclePlate || '',
    vehicleYear: job?.vehicleYear || '',
    serviceDescription: job?.serviceDescription || '',
    estimatedHours: job?.estimatedHours || '',
    estimatedCost: job?.estimatedCost || '',
    technicianId: job?.technicianId || '',
    priority: job?.priority || 'Medium',
    dueDate: job?.dueDate || '',
    notes: job?.notes || '',
    vehiclePhotos: job?.vehiclePhotos || []
  });

  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Auto-fill customer details when customer is selected
    if (name === 'customerId') {
      const selectedCustomer = customers.find(c => c.id === value);
      if (selectedCustomer) {
        setFormData(prev => ({
          ...prev,
          customerName: selectedCustomer.name
        }));
      }
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFiles = (files) => {
    const newPhotos = Array.from(files).map(file => ({
      id: Date.now() + Math.random(),
      file,
      url: URL.createObjectURL(file),
      name: file.name
    }));

    setFormData(prev => ({
      ...prev,
      vehiclePhotos: [...prev.vehiclePhotos, ...newPhotos]
    }));
  };

  const removePhoto = (photoId) => {
    setFormData(prev => ({
      ...prev,
      vehiclePhotos: prev.vehiclePhotos.filter(photo => photo.id !== photoId)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="bg-surface rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-heading-semibold text-text-primary">
          {isEditing ? 'Edit Job Card' : 'Create New Job Card'}
        </h2>
        <Button variant="ghost" onClick={onCancel}>
          <Icon name="X" size={20} />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Customer Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-body-medium text-text-primary mb-2">
              Customer *
            </label>
            <select
              name="customerId"
              value={formData.customerId}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
            >
              <option value="">Select Customer</option>
              {customers.map(customer => (
                <option key={customer.id} value={customer.id}>
                  {customer.name} - {customer.phone}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-body-medium text-text-primary mb-2">
              Priority
            </label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>

        {/* Vehicle Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-heading-medium text-text-primary">Vehicle Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              type="text"
              name="vehicleModel"
              placeholder="Vehicle Model"
              value={formData.vehicleModel}
              onChange={handleInputChange}
              required
            />
            <Input
              type="text"
              name="vehiclePlate"
              placeholder="License Plate"
              value={formData.vehiclePlate}
              onChange={handleInputChange}
              required
            />
            <Input
              type="number"
              name="vehicleYear"
              placeholder="Year"
              value={formData.vehicleYear}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>

        {/* Service Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-heading-medium text-text-primary">Service Details</h3>
          <div>
            <label className="block text-sm font-body-medium text-text-primary mb-2">
              Service Description *
            </label>
            <textarea
              name="serviceDescription"
              value={formData.serviceDescription}
              onChange={handleInputChange}
              placeholder="Describe the service required..."
              rows={4}
              required
              className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent resize-none"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              type="number"
              name="estimatedHours"
              placeholder="Estimated Hours"
              value={formData.estimatedHours}
              onChange={handleInputChange}
              required
            />
            <Input
              type="number"
              name="estimatedCost"
              placeholder="Estimated Cost ($)"
              value={formData.estimatedCost}
              onChange={handleInputChange}
              required
            />
            <Input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>

        {/* Technician Assignment */}
        <div>
          <label className="block text-sm font-body-medium text-text-primary mb-2">
            Assign Technician *
          </label>
          <select
            name="technicianId"
            value={formData.technicianId}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
          >
            <option value="">Select Technician</option>
            {technicians.map(tech => (
              <option key={tech.id} value={tech.id}>
                {tech.name} - {tech.specialization}
              </option>
            ))}
          </select>
        </div>

        {/* Vehicle Photos */}
        <div className="space-y-4">
          <h3 className="text-lg font-heading-medium text-text-primary">Vehicle Photos</h3>
          
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center micro-interaction ${
              dragActive ? 'border-accent bg-accent/5' : 'border-border hover:border-accent/50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Icon name="Upload" size={32} className="mx-auto text-text-secondary mb-2" />
            <p className="text-text-secondary mb-2">
              Drag and drop photos here, or{' '}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-accent hover:underline"
              >
                browse files
              </button>
            </p>
            <p className="text-xs text-text-secondary">PNG, JPG up to 10MB each</p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => handleFiles(e.target.files)}
              className="hidden"
            />
          </div>

          {formData.vehiclePhotos.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {formData.vehiclePhotos.map(photo => (
                <div key={photo.id} className="relative group">
                  <Image
                    src={photo.url}
                    alt={photo.name}
                    className="w-full h-24 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => removePhoto(photo.id)}
                    className="absolute -top-2 -right-2 bg-error text-error-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 micro-interaction"
                  >
                    <Icon name="X" size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-body-medium text-text-primary mb-2">
            Additional Notes
          </label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleInputChange}
            placeholder="Any additional notes or special instructions..."
            rows={3}
            className="w-full px-3 py-2 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent resize-none"
          />
        </div>

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-4 pt-6 border-t border-border">
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button variant="primary" type="submit">
            {isEditing ? 'Update Job Card' : 'Create Job Card'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default JobForm;