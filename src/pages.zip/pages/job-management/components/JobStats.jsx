import React from 'react';
import Icon from '../../../components/AppIcon';

const JobStats = ({ jobs }) => {
  const totalJobs = jobs.length;
  const pendingJobs = jobs.filter(job => job.status === 'Pending').length;
  const inProgressJobs = jobs.filter(job => job.status === 'In Progress').length;
  const completedJobs = jobs.filter(job => job.status === 'Completed').length;
  const highPriorityJobs = jobs.filter(job => job.priority === 'High').length;

  const stats = [
    {
      label: 'Total Jobs',
      value: totalJobs,
      icon: 'Clipboard',
      color: 'text-text-primary',
      bgColor: 'bg-background'
    },
    {
      label: 'Pending',
      value: pendingJobs,
      icon: 'Clock',
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    },
    {
      label: 'In Progress',
      value: inProgressJobs,
      icon: 'Wrench',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      label: 'Completed',
      value: completedJobs,
      icon: 'CheckCircle',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      label: 'High Priority',
      value: highPriorityJobs,
      icon: 'AlertTriangle',
      color: 'text-error',
      bgColor: 'bg-error/10'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {stats.map((stat, index) => (
        <div key={index} className={`${stat.bgColor} rounded-lg p-4`}>
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg bg-surface`}>
              <Icon name={stat.icon} size={20} className={stat.color} />
            </div>
            <div>
              <p className="text-2xl font-heading-semibold text-text-primary">{stat.value}</p>
              <p className="text-sm text-text-secondary">{stat.label}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default JobStats;