
import React, { useState, useMemo, useContext } from 'react';
import { InventoryProvider, useInventory } from './InventoryContext';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Icon from '../../components/AppIcon';
import Input from '../../components/ui/Input';
import CategorySidebar from './components/CategorySidebar';
import InventoryTable from './components/InventoryTable';
import AlertsPanel from './components/AlertsPanel';
import AssignToJobModal from './components/AssignToJobModal';
import EditPartModal from './components/EditPartModal';

const InventoryManagement = () => {
  const { parts = [] } = useInventory() || {};
  // If you have categories, lowStockAlerts, recentTransactions in context, add them to the provider value and destructure here
  const categories = [];
  const lowStockAlerts = [];
  const recentTransactions = [];
  const [filters, setFilters] = useState({
    search: '',
    supplier: '',
    stockStatus: 'all',
    priceRange: { min: '', max: '' }
  });
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedParts, setSelectedParts] = useState([]);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedPart, setSelectedPart] = useState(null);
  const [sortConfig, setSortConfig] = useState({ key: '', direction: '' });

  const handleCategorySelect = (cat) => setSelectedCategory(cat);
  const handleFilterChange = (newFilters) => setFilters(newFilters);
  const handlePartSelect = (part) => setSelectedParts([part]);
  const handleSelectAll = () => setSelectedParts(parts);
  const handleEditPart = (part) => { setSelectedPart(part); setShowEditModal(true); };
  const handleAssignToJob = (part) => { setSelectedPart(part); setShowAssignModal(true); };
  const handleViewHistory = (part) => {};
  const handleReorderPart = (part) => {};
  const handleViewTransaction = (transaction) => {};
  const handleAssignPart = (assignmentData) => setShowAssignModal(false);
  const handleSavePart = (updatedPart) => setShowEditModal(false);
  const handleSort = (config) => setSortConfig(config);

  // Filter and sort parts
  const filteredParts = useMemo(() => {
    let filtered = parts;
    if (selectedCategory !== 'all') {
      const category = categories.find(c => c.id === selectedCategory);
      if (category) {
        filtered = filtered.filter(p => p.category === category.name);
      }
    }
    if (filters.search) {
      filtered = filtered.filter(part =>
        part.partNumber?.toLowerCase().includes(filters.search.toLowerCase()) ||
        part.description?.toLowerCase().includes(filters.search.toLowerCase())
      );
    }
    if (filters.supplier) {
      filtered = filtered.filter(part => part.supplier === filters.supplier);
    }
    if (filters.stockStatus !== 'all') {
      if (filters.stockStatus === 'in-stock') {
        filtered = filtered.filter(part => part.currentStock > part.minimumThreshold);
      } else if (filters.stockStatus === 'low-stock') {
        filtered = filtered.filter(part => part.currentStock <= part.minimumThreshold && part.currentStock > 0);
      } else if (filters.stockStatus === 'out-of-stock') {
        filtered = filtered.filter(part => part.currentStock === 0);
      }
    }
    // Add sort logic if needed
    return filtered;
  }, [parts, categories, selectedCategory, filters]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16">
        <div className="px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-heading-semibold text-text-primary">Inventory Management</h1>
                <p className="text-text-secondary mt-1">Track parts, monitor stock levels, and manage inventory</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" />
                  <Input
                    type="search"
                    placeholder="Search parts..."
                    value={filters.search}
                    onChange={(e) => handleFilterChange({ ...filters, search: e.target.value })}
                    className="pl-10 w-80"
                  />
                </div>
              </div>
            </div>
          </div>
          {/* Main Content */}
          <div className="grid grid-cols-12 gap-6">
            {/* Left Sidebar - Categories and Filters */}
            <div className="col-span-12 lg:col-span-3">
              <CategorySidebar
                categories={categories}
                selectedCategory={selectedCategory}
                onCategorySelect={handleCategorySelect}
                filters={filters}
                onFilterChange={handleFilterChange}
              />
            </div>
            {/* Center - Inventory Table */}
            <div className="col-span-12 lg:col-span-6">
              <InventoryTable
                parts={filteredParts}
                selectedParts={selectedParts}
                onPartSelect={handlePartSelect}
                onSelectAll={handleSelectAll}
                onEditPart={handleEditPart}
                onAssignToJob={handleAssignToJob}
                onViewHistory={handleViewHistory}
                sortConfig={sortConfig}
                onSort={handleSort}
              />
            </div>
            {/* Right Panel - Alerts and Actions */}
            <div className="col-span-12 lg:col-span-3">
              <AlertsPanel
                lowStockAlerts={lowStockAlerts}
                recentTransactions={recentTransactions}
                onReorderPart={handleReorderPart}
                onViewTransaction={handleViewTransaction}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Modals */}
      <AssignToJobModal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        part={selectedPart}
        onAssign={handleAssignPart}
      />
      <EditPartModal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        part={selectedPart}
        onSave={handleSavePart}
      />
    </div>
  );
};

const WrappedInventoryManagement = () => (
  <InventoryProvider>
    <InventoryManagement />
  </InventoryProvider>
);

export default WrappedInventoryManagement;