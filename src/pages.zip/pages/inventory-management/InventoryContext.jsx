import React, { createContext, useContext, useState } from 'react';

const InventoryContext = createContext();

const initialParts = [
  {
    id: 'P-1001',
    partNumber: 'BP-001',
    description: 'Brake Pad Set - Front',
    category: 'Brakes',
    currentStock: 24,
    minimumThreshold: 6,
    supplier: 'ABC Parts',
    unitCost: 35.5,
    unit: 'pcs'
  },
  {
    id: 'P-1002',
    partNumber: 'BAT-002',
    description: '12V Car Battery',
    category: 'Electrical',
    currentStock: 12,
    minimumThreshold: 3,
    supplier: 'PowerCells Ltd',
    unitCost: 120.0,
    unit: 'pcs'
  },
  {
    id: 'P-1003',
    partNumber: 'OIL-5W30',
    description: 'Engine Oil 5W-30 (1L)',
    category: 'Fluids',
    currentStock: 48,
    minimumThreshold: 10,
    supplier: 'LubriCo',
    unitCost: 9.75,
    unit: 'btl'
  }
];

export const InventoryProvider = ({ children }) => {
  const [parts, setParts] = useState(initialParts);
  return (
    <InventoryContext.Provider value={{ parts, setParts }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => useContext(InventoryContext);
