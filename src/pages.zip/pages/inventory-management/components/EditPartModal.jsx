import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const EditPartModal = ({ isOpen, onClose, part, onSave }) => {
  const [formData, setFormData] = useState({
    partNumber: '',
    description: '',
    category: '',
    supplier: '',
    unitCost: '',
    currentStock: '',
    minimumThreshold: '',
    unit: '',
    location: '',
    notes: ''
  });

  const categories = [
    'Engine Parts',
    'Brake System',
    'Suspension',
    'Electrical',
    'Body Parts',
    'Filters',
    'Fluids',
    'Tools'
  ];

  const suppliers = [
    'AutoParts Plus',
    'Premium Motors',
    'Global Auto Supply',
    'QuickFix Parts'
  ];

  const units = ['pcs', 'liters', 'kg', 'meters', 'sets'];

  useEffect(() => {
    if (part) {
      setFormData({
        partNumber: part.partNumber || '',
        description: part.description || '',
        category: part.category || '',
        supplier: part.supplier || '',
        unitCost: part.unitCost || '',
        currentStock: part.currentStock || '',
        minimumThreshold: part.minimumThreshold || '',
        unit: part.unit || '',
        location: part.location || '',
        notes: part.notes || ''
      });
    }
  }, [part]);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...part,
      ...formData,
      unitCost: parseFloat(formData.unitCost),
      currentStock: parseInt(formData.currentStock),
      minimumThreshold: parseInt(formData.minimumThreshold)
    });
    onClose();
  };

  if (!isOpen || !part) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal">
      <div className="bg-surface rounded-lg border border-border w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-border sticky top-0 bg-surface">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-heading-medium text-text-primary">Edit Part</h3>
            <Button variant="ghost" onClick={onClose} className="p-2">
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Part Number */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Part Number <span className="text-error">*</span>
              </label>
              <Input
                type="text"
                value={formData.partNumber}
                onChange={(e) => handleChange('partNumber', e.target.value)}
                required
                placeholder="Enter part number"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Description <span className="text-error">*</span>
              </label>
              <Input
                type="text"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                required
                placeholder="Enter description"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Category <span className="text-error">*</span>
              </label>
              <select
                value={formData.category}
                onChange={(e) => handleChange('category', e.target.value)}
                required
                className="w-full p-3 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent"
              >
                <option value="">Select category</option>
                {categories.map((category) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>

            {/* Supplier */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Supplier <span className="text-error">*</span>
              </label>
              <select
                value={formData.supplier}
                onChange={(e) => handleChange('supplier', e.target.value)}
                required
                className="w-full p-3 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent"
              >
                <option value="">Select supplier</option>
                {suppliers.map((supplier) => (
                  <option key={supplier} value={supplier}>{supplier}</option>
                ))}
              </select>
            </div>

            {/* Unit Cost */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Unit Cost <span className="text-error">*</span>
              </label>
              <Input
                type="number"
                value={formData.unitCost}
                onChange={(e) => handleChange('unitCost', e.target.value)}
                required
                min="0"
                step="0.01"
                placeholder="0.00"
              />
            </div>

            {/* Current Stock */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Current Stock <span className="text-error">*</span>
              </label>
              <Input
                type="number"
                value={formData.currentStock}
                onChange={(e) => handleChange('currentStock', e.target.value)}
                required
                min="0"
                placeholder="Enter current stock"
              />
            </div>

            {/* Minimum Threshold */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Minimum Threshold <span className="text-error">*</span>
              </label>
              <Input
                type="number"
                value={formData.minimumThreshold}
                onChange={(e) => handleChange('minimumThreshold', e.target.value)}
                required
                min="0"
                placeholder="Enter minimum threshold"
              />
            </div>

            {/* Unit */}
            <div>
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Unit <span className="text-error">*</span>
              </label>
              <select
                value={formData.unit}
                onChange={(e) => handleChange('unit', e.target.value)}
                required
                className="w-full p-3 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent"
              >
                <option value="">Select unit</option>
                {units.map((unit) => (
                  <option key={unit} value={unit}>{unit}</option>
                ))}
              </select>
            </div>

            {/* Location */}
            <div className="md:col-span-2">
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Storage Location
              </label>
              <Input
                type="text"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="e.g., Shelf A-1, Bin 23"
              />
            </div>

            {/* Notes */}
            <div className="md:col-span-2">
              <label className="block text-sm font-body-medium text-text-primary mb-2">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                rows="3"
                placeholder="Additional notes about this part..."
                className="w-full p-3 border border-border rounded-lg bg-surface text-text-primary focus:outline-none focus:ring-2 focus:ring-accent resize-none"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-6 mt-6 border-t border-border">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              Save Changes
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditPartModal;