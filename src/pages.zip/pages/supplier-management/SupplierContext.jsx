import React, { createContext, useContext, useState } from 'react';

const SupplierContext = createContext();

const initialSuppliers = [
  {
    id: 1,
    name: 'ABC Parts',
    contact: 'John Doe',
    phone: '123-456-7890',
    amount: 1200,
    dueDate: '2025-08-20',
    state: 'due',
    productsSupplied: 'Alternators, Spark Plugs',
    previous: [
      { date: '2025-07-10', amount: 800 },
    ],
    future: [
      { date: '2025-09-10', amount: 1500 },
    ],
    payments: [
      { date: '2025-07-15', amount: 800 },
    ],
  },
  {
    id: 2,
    name: 'XYZ Supplies',
    contact: 'Jane Smith',
    phone: '987-654-3210',
    amount: 600,
    dueDate: '2025-08-10',
    state: 'overdue',
    productsSupplied: 'Brake Pads, Oil Filters',
    previous: [
      { date: '2025-07-20', amount: 400 },
    ],
    future: [
      { date: '2025-09-20', amount: 700 },
    ],
    payments: [
      { date: '2025-07-25', amount: 400 },
    ],
  },
];

export const SupplierProvider = ({ children }) => {
  const [suppliers, setSuppliers] = useState(initialSuppliers);
  return (
    <SupplierContext.Provider value={{ suppliers, setSuppliers }}>
      {children}
    </SupplierContext.Provider>
  );
};

export const useSuppliers = () => useContext(SupplierContext);
