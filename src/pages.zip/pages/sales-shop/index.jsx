import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import { SalesProvider } from './SalesContext';
import SalesList from './components/SalesList';
import AddSaleModal from './components/AddSaleModal';
import { useSales } from './SalesContext';

const SalesShop = () => {
  const [showAdd, setShowAdd] = useState(false);
  const [editingSale, setEditingSale] = useState(null);
  const { removeSale } = useSales();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          <div className="bg-surface rounded-lg border border-border shadow-lg p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
              <div>
                <h1 className="text-2xl font-heading-semibold text-text-primary">Parts Sales Shop</h1>
                <p className="text-text-secondary mt-1">Sell motor parts and record transactions into the financials</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm text-text-secondary">Total Sales</div>
                </div>
                <button
                  className="modern-button bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow hover:bg-primary/90"
                  onClick={() => setShowAdd(true)}
                >
                  New Sale
                </button>
              </div>
            </div>

    <SalesList onEdit={(s) => setEditingSale(s)} onDelete={(id) => removeSale(id)} />
          </div>
        </div>
      </main>
  <AddSaleModal isOpen={showAdd} onClose={() => setShowAdd(false)} />
  <AddSaleModal isOpen={!!editingSale} onClose={() => setEditingSale(null)} sale={editingSale} />
    </div>
  );
};

const WrappedSalesShop = () => (
  <SalesProvider>
    <SalesShop />
  </SalesProvider>
);

export default WrappedSalesShop;
