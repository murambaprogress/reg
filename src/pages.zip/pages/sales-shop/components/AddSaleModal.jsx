import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { useSales } from '../SalesContext';

const AddSaleModal = ({ isOpen, onClose, sale = null }) => {
  const { addSale, editSale } = useSales();
  const [customer, setCustomer] = useState(sale?.customer || '');
  const [items, setItems] = useState(sale?.items || [{ name: '', qty: 1, unit: 0 }]);

  if (!isOpen) return null;

  const handleItemChange = (index, key, value) => {
    const next = [...items];
    next[index][key] = value;
    setItems(next);
  };

  const addItem = () => setItems(prev => [...prev, { name: '', qty: 1, unit: 0 }]);
  const removeItem = (index) => setItems(prev => prev.filter((_, i) => i !== index));

  const handleSubmit = () => {
    const total = items.reduce((sum, it) => sum + (Number(it.qty) * Number(it.unit || 0)), 0);
    if (sale && sale.id) {
      editSale(sale.id, { customer, items, total });
    } else {
      addSale({ customer, items, total });
    }
    setCustomer('');
    setItems([{ name: '', qty: 1, unit: 0 }]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-surface rounded-lg p-6 w-full max-w-2xl">
        <h3 className="text-lg font-heading-medium text-text-primary mb-4">New Sale</h3>
  <div className="space-y-3">
          <Input placeholder="Customer name (optional)" value={customer} onChange={(e) => setCustomer(e.target.value)} />

          <div className="space-y-2">
            {items.map((it, idx) => (
              <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                <input className="col-span-6 p-2 border border-border rounded" placeholder="Item name" value={it.name} onChange={(e) => handleItemChange(idx, 'name', e.target.value)} />
                <input type="number" className="col-span-2 p-2 border border-border rounded" value={it.qty} onChange={(e) => handleItemChange(idx, 'qty', e.target.value)} />
                <input type="number" className="col-span-3 p-2 border border-border rounded" value={it.unit} onChange={(e) => handleItemChange(idx, 'unit', e.target.value)} placeholder="Unit price" />
                <button className="col-span-1 p-2 text-sm text-error" onClick={() => removeItem(idx)}>Remove</button>
              </div>
            ))}
            <button className="text-sm text-primary" onClick={addItem}>+ Add item</button>
          </div>

            <div className="flex items-center justify-end space-x-2 mt-4">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSubmit}>{sale ? 'Update Sale' : 'Save Sale'}</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddSaleModal;
