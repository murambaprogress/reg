import React from 'react';
import { useSales } from '../SalesContext';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SalesList = () => {
  const { sales, totalSales } = useSales();

  const formatCurrency = (amount) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div className="text-sm text-text-secondary">{sales.length} transactions</div>
        <div className="text-lg font-heading-medium text-text-primary">Total: {formatCurrency(totalSales)}</div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-background/50">
            <tr>
              <th className="p-4 text-left">#</th>
              <th className="p-4 text-left">Date</th>
              <th className="p-4 text-left">Customer</th>
              <th className="p-4 text-left">Items</th>
              <th className="p-4 text-left">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sales.map((s, i) => (
              <tr key={s.id} className="hover:bg-background/50 micro-interaction">
                <td className="p-4">{i + 1}</td>
                <td className="p-4">{new Date(s.date).toLocaleString()}</td>
                <td className="p-4">{s.customer || 'Walk-in'}</td>
                <td className="p-4">
                  {s.items?.map((it, idx) => (
                    <div key={idx} className="text-sm text-text-secondary">{it.qty} x {it.name} @ ${it.unit}</div>
                  ))}
                </td>
                <td className="p-4">${Number(s.total).toFixed(2)}</td>
                <td className="p-4">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => onEdit(s)}>
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm" className="text-error" onClick={() => onDelete(s.id)}>
                      Delete
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {sales.length === 0 && (
              <tr>
                <td className="p-6 text-text-secondary" colSpan={5}>No sales yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesList;
