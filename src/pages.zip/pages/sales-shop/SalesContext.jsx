import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { useInventory } from '../../pages/inventory-management/InventoryContext';

const SalesContext = createContext();

export const useSales = () => useContext(SalesContext);

export const SalesProvider = ({ children }) => {
  // read inventory hook first (must be called unconditionally)
  const { parts, setParts } = useInventory() || { parts: [], setParts: () => {} };

  // In-memory sales; replace with API integration later
  const mockSales = [
    {
      id: 'SALE-MOCK-1',
      date: new Date().toISOString(),
      customer: 'Walk-in',
      items: [
        { partNumber: 'BP-001', name: 'Brake Pad Set - Front', qty: 2, unit: 45.0 },
        { name: 'Engine Oil 5W-30 (1L)', qty: 1, unit: 10.0 }
      ],
      total: 100.0
    },
    {
      id: 'SALE-MOCK-2',
      date: new Date().toISOString(),
      customer: 'John Doe',
      items: [
        { partNumber: 'BAT-002', name: '12V Car Battery', qty: 1, unit: 150.0 }
      ],
      total: 150.0
    }
  ];

  const [sales, setSales] = useState(mockSales);

  // Apply initial inventory adjustments for mock sales once
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (!parts || parts.length === 0 || !sales || sales.length === 0) return;
    try {
      const adjusted = parts.map(p => {
        const soldQty = sales.reduce((acc, sale) => {
          return acc + (sale.items?.reduce((s, it) => {
            if (it.partNumber && p.partNumber === it.partNumber) return s + Number(it.qty || 0);
            if (!it.partNumber && p.description && p.description.toLowerCase().includes((it.name || '').toLowerCase())) return s + Number(it.qty || 0);
            return s;
          }, 0) || 0);
        }, 0);
        if (soldQty > 0) return { ...p, currentStock: Math.max(0, Number(p.currentStock || 0) - soldQty) };
        return p;
      });
      setParts(adjusted);
      seededRef.current = true;
    } catch (e) {
      console.warn('Failed to apply initial mock sales to inventory', e);
    }
  }, [parts, sales, setParts]);

  const addSale = (sale) => {
    const id = `SALE-${Date.now()}`;
    const newSale = { id, date: new Date().toISOString(), ...sale };
    setSales(prev => [newSale, ...prev]);

    // Decrement inventory for sold items (best-effort: match by partNumber or name)
    try {
      if (parts && parts.length > 0) {
        const updatedParts = parts.map(p => {
          const soldQty = sale.items?.reduce((s, it) => {
            // match by partNumber first, then by name
            if (it.partNumber && p.partNumber === it.partNumber) return s + Number(it.qty || 0);
            if (!it.partNumber && p.description && p.description.toLowerCase().includes((it.name || '').toLowerCase())) return s + Number(it.qty || 0);
            return s;
          }, 0);
          if (soldQty > 0) {
            return { ...p, currentStock: Math.max(0, Number(p.currentStock || 0) - soldQty) };
          }
          return p;
        });
        setParts(updatedParts);
      }
    } catch (e) {
      console.warn('Failed to update inventory for sale', e);
    }
    return newSale;
  };

  const editSale = (saleId, updatedSale) => {
    setSales(prev => prev.map(s => s.id === saleId ? { ...s, ...updatedSale } : s));
    // For simplicity, inventory adjustments on edit are not fully reconciled here.
    // A robust implementation would diff old vs new items and update inventory accordingly.
  };

  const removeSale = (saleId) => {
    const saleToRemove = sales.find(s => s.id === saleId);
    setSales(prev => prev.filter(s => s.id !== saleId));
    // Attempt to restore inventory
    try {
      if (saleToRemove && parts && parts.length > 0) {
        const updatedParts = parts.map(p => {
          const restoreQty = saleToRemove.items?.reduce((s, it) => {
            if (it.partNumber && p.partNumber === it.partNumber) return s + Number(it.qty || 0);
            if (!it.partNumber && p.description && p.description.toLowerCase().includes((it.name || '').toLowerCase())) return s + Number(it.qty || 0);
            return s;
          }, 0);
          if (restoreQty > 0) {
            return { ...p, currentStock: Number(p.currentStock || 0) + restoreQty };
          }
          return p;
        });
        setParts(updatedParts);
      }
    } catch (e) {
      console.warn('Failed to restore inventory for removed sale', e);
    }
  };

  const totalSales = sales.reduce((sum, s) => sum + (Number(s.total) || 0), 0);

  return (
    <SalesContext.Provider value={{ sales, addSale, editSale, removeSale, totalSales }}>
      {children}
    </SalesContext.Provider>
  );
};

export default SalesContext;
