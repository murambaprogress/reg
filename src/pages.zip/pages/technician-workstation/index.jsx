import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import JobCard from './components/JobCard';
import ActiveJobTimer from './components/ActiveJobTimer';
import PhotoCapture from './components/PhotoCapture';
import PartsRequest from './components/PartsRequest';
import QuickActions from './components/QuickActions';
import JobDetailsModal from './components/JobDetailsModal';

const TechnicianWorkstation = () => {
  const [assignedJobs, setAssignedJobs] = useState([]);
  const [activeJob, setActiveJob] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);
  const [isJobDetailsOpen, setIsJobDetailsOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);

  // Mock data for assigned jobs
  const mockJobs = [
    {
      id: 'JOB-2024-001',
      jobNumber: 'JOB-2024-001',
      customerName: 'John Smith',
      customerPhone: '(555) 123-4567',
      customerEmail: 'john.smith@email.com',
      vehicleInfo: '2020 Honda Civic',
      vehicleYear: '2020',
      vehicleVin: '1HGBH41JXMN109186',
      licensePlate: 'ABC-1234',
      mileage: '45,230',
      vehicleImage: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400&h=300&fit=crop',
      serviceDescription: 'Regular maintenance service including oil change, filter replacement, and general inspection',
      services: ['Oil Change', 'Filter Replacement', 'Brake Inspection'],
      status: 'Assigned',
      priority: 'Medium',
      estimatedTime: '2 hours',
      createdDate: '2024-01-15',
      notes: 'Customer mentioned unusual noise from brakes',
      elapsedTime: 0
    },
    {
      id: 'JOB-2024-002',
      jobNumber: 'JOB-2024-002',
      customerName: 'Sarah Johnson',
      customerPhone: '(555) 987-6543',
      customerEmail: 'sarah.johnson@email.com',
      vehicleInfo: '2019 Toyota Camry',
      vehicleYear: '2019',
      vehicleVin: '4T1BF1FK5KU123456',
      licensePlate: 'XYZ-5678',
      mileage: '62,150',
      vehicleImage: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=300&fit=crop',
      serviceDescription: 'Brake system repair and replacement of worn brake pads',
      services: ['Brake Pad Replacement', 'Brake Fluid Change', 'Rotor Inspection'],
      status: 'Assigned',
      priority: 'High',
      estimatedTime: '3 hours',
      createdDate: '2024-01-15',
      notes: 'Priority job - customer needs vehicle by 3 PM',
      elapsedTime: 0
    },
    {
      id: 'JOB-2024-003',
      jobNumber: 'JOB-2024-003',
      customerName: 'Mike Davis',
      customerPhone: '(555) 456-7890',
      customerEmail: 'mike.davis@email.com',
      vehicleInfo: '2021 Ford F-150',
      vehicleYear: '2021',
      vehicleVin: '1FTFW1ET5MKE12345',
      licensePlate: 'DEF-9012',
      mileage: '28,500',
      vehicleImage: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop',
      serviceDescription: 'Transmission service and fluid replacement',
      services: ['Transmission Service', 'Fluid Replacement', 'Filter Change'],
      status: 'In Progress',
      priority: 'Low',
      estimatedTime: '4 hours',
      createdDate: '2024-01-14',
      notes: 'Started yesterday, continuing today',
      elapsedTime: 3600
    }
  ];

  useEffect(() => {
    setAssignedJobs(mockJobs);
    // Set active job if there's one in progress
    const inProgressJob = mockJobs.find(job => job.status === 'In Progress');
    if (inProgressJob) {
      setActiveJob(inProgressJob);
    }
  }, []);

  const handleStartJob = (job) => {
    const updatedJob = { ...job, status: 'In Progress', elapsedTime: 0 };
    setActiveJob(updatedJob);
    setAssignedJobs(prev => prev.map(j => j.id === job.id ? updatedJob : j));
    
    // Add notification
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Started job ${job.jobNumber}`,
      type: 'success',
      timestamp: new Date()
    }]);
  };

  const handlePauseJob = (jobId, elapsedTime) => {
    setActiveJob(prev => prev ? { ...prev, status: 'Paused', elapsedTime } : null);
    setAssignedJobs(prev => prev.map(j => 
      j.id === jobId ? { ...j, status: 'Paused', elapsedTime } : j
    ));
  };

  const handleResumeJob = (jobId) => {
    setActiveJob(prev => prev ? { ...prev, status: 'In Progress' } : null);
    setAssignedJobs(prev => prev.map(j => 
      j.id === jobId ? { ...j, status: 'In Progress' } : j
    ));
  };

  const handleCompleteJob = (jobId) => {
    setActiveJob(null);
    setAssignedJobs(prev => prev.map(j => 
      j.id === jobId ? { ...j, status: 'Completed' } : j
    ));
    
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Completed job ${jobId}`,
      type: 'success',
      timestamp: new Date()
    }]);
  };

  const handleUpdateProgress = (jobId, status, notes) => {
    setAssignedJobs(prev => prev.map(j => 
      j.id === jobId ? { ...j, status, notes: j.notes + `\n${new Date().toLocaleString()}: ${notes}` } : j
    ));
    
    if (activeJob && activeJob.id === jobId) {
      setActiveJob(prev => ({ ...prev, status, notes: prev.notes + `\n${new Date().toLocaleString()}: ${notes}` }));
    }
  };

  const handleViewDetails = (job) => {
    setSelectedJob(job);
    setIsJobDetailsOpen(true);
  };

  const handlePhotoCapture = (jobId, photo) => {
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Photo captured for job ${jobId}`,
      type: 'info',
      timestamp: new Date()
    }]);
  };

  const handleRequestParts = (jobId, parts, notes) => {
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Parts requested for job ${jobId}`,
      type: 'info',
      timestamp: new Date()
    }]);
  };

  const handleContactCustomer = (phone, type = 'call') => {
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `${type === 'call' ? 'Called' : 'Texted'} customer at ${phone}`,
      type: 'info',
      timestamp: new Date()
    }]);
  };

  const handleViewHistory = (vehicleId) => {
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Viewed service history for vehicle ${vehicleId}`,
      type: 'info',
      timestamp: new Date()
    }]);
  };

  const handleMessageSupervisor = (jobId, message) => {
    setNotifications(prev => [...prev, {
      id: Date.now(),
      message: `Message sent to supervisor about job ${jobId}`,
      type: 'success',
      timestamp: new Date()
    }]);
  };

  const handleUpdateJob = (jobId, updates) => {
    setAssignedJobs(prev => prev.map(j => 
      j.id === jobId ? { ...j, ...updates } : j
    ));
    
    if (selectedJob && selectedJob.id === jobId) {
      setSelectedJob(prev => ({ ...prev, ...updates }));
    }
  };

  const pendingJobs = assignedJobs.filter(job => job.status === 'Assigned');
  const inProgressJobs = assignedJobs.filter(job => job.status === 'In Progress' || job.status === 'Paused');
  const completedJobs = assignedJobs.filter(job => job.status === 'Completed');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb />
          
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-heading-bold text-text-primary">Technician Workstation</h1>
              <p className="text-text-secondary mt-1">Manage your assigned jobs and track progress</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-success rounded-full"></div>
                <span className="text-sm text-text-secondary">Online</span>
              </div>
              <Button variant="outline" className="text-sm">
                <Icon name="RefreshCw" size={16} className="mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Notifications */}
          {notifications.length > 0 && (
            <div className="mb-6">
              <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Bell" size={16} className="text-accent" />
                  <span className="text-sm font-body-medium text-accent">Recent Activity</span>
                </div>
                <div className="space-y-1">
                  {notifications.slice(-3).map(notification => (
                    <p key={notification.id} className="text-sm text-text-secondary">
                      {notification.message} - {notification.timestamp.toLocaleTimeString()}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Active Job Timer */}
              {activeJob && (
                <ActiveJobTimer
                  job={activeJob}
                  onPause={handlePauseJob}
                  onResume={handleResumeJob}
                  onComplete={handleCompleteJob}
                  onUpdateProgress={handleUpdateProgress}
                />
              )}

              {/* Job Sections */}
              <div className="space-y-6">
                {/* Pending Jobs */}
                {pendingJobs.length > 0 && (
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Icon name="Clock" size={20} className="text-warning" />
                      <h2 className="text-lg font-heading-semibold text-text-primary">
                        Pending Jobs ({pendingJobs.length})
                      </h2>
                    </div>
                    <div className="grid grid-cols-1 gap-4">
                      {pendingJobs.map(job => (
                        <JobCard
                          key={job.id}
                          job={job}
                          onStartJob={handleStartJob}
                          onViewDetails={handleViewDetails}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* In Progress Jobs */}
                {inProgressJobs.length > 0 && (
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Icon name="Wrench" size={20} className="text-accent" />
                      <h2 className="text-lg font-heading-semibold text-text-primary">
                        In Progress ({inProgressJobs.length})
                      </h2>
                    </div>
                    <div className="grid grid-cols-1 gap-4">
                      {inProgressJobs.map(job => (
                        <JobCard
                          key={job.id}
                          job={job}
                          onStartJob={handleStartJob}
                          onViewDetails={handleViewDetails}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Completed Jobs */}
                {completedJobs.length > 0 && (
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Icon name="CheckCircle" size={20} className="text-success" />
                      <h2 className="text-lg font-heading-semibold text-text-primary">
                        Completed Today ({completedJobs.length})
                      </h2>
                    </div>
                    <div className="grid grid-cols-1 gap-4">
                      {completedJobs.map(job => (
                        <JobCard
                          key={job.id}
                          job={job}
                          onStartJob={handleStartJob}
                          onViewDetails={handleViewDetails}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Photo Capture */}
              <PhotoCapture
                jobId={activeJob?.id}
                onPhotoCapture={handlePhotoCapture}
              />

              {/* Parts Request */}
              <PartsRequest
                jobId={activeJob?.id}
                onRequestParts={handleRequestParts}
              />
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <QuickActions
                currentJob={activeJob}
                onContactCustomer={handleContactCustomer}
                onViewHistory={handleViewHistory}
                onMessageSupervisor={handleMessageSupervisor}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Job Details Modal */}
      <JobDetailsModal
        job={selectedJob}
        isOpen={isJobDetailsOpen}
        onClose={() => setIsJobDetailsOpen(false)}
        onUpdateJob={handleUpdateJob}
      />
    </div>
  );
};

export default TechnicianWorkstation;