import React, { createContext, useContext, useState } from 'react';

const CustomerContext = createContext();

const initialCustomers = [
  // Add your initial customer objects here, or fetch from backend in future
];

export const CustomerProvider = ({ children }) => {
  const [customers, setCustomers] = useState(initialCustomers);
  return (
    <CustomerContext.Provider value={{ customers, setCustomers }}>
      {children}
    </CustomerContext.Provider>
  );
};

export const useCustomers = () => useContext(CustomerContext);
